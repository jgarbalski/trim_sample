import logging
from typing import Any

import optuna
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split

optuna.logging.set_verbosity(optuna.logging.WARNING)

logger = logging.getLogger(__name__)


def objective(
    trial: optuna.Trial,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    cfg: dict[str, Any],
) -> float:
    """Optuna objective function for LightGBM hyperparameter search.

    Performs a stratified internal train/validation split to evaluate each trial.
    Each trial uses a different random seed (trial.number) so the evaluation
    is not biased towards hyperparameters that happen to overfit one specific split.
    The num_leaves parameter is capped at 2^max_depth - 1 to avoid invalid
    LightGBM configurations.

    Args:
        trial: Optuna trial object.
        X_train: Training features.
        y_train: Training labels.
        cfg: Full configuration dict.

    Returns:
        Validation F1 score for the trial.
    """
    train_cfg = cfg["training"]
    search_space = train_cfg["hyperparameter_search_space"]

    # Use trial.number as seed so each trial evaluates on a different split,
    # preventing bias towards params that overfit one particular validation fold.
    X_sub, X_val, y_sub, y_val = train_test_split(
        X_train,
        y_train,
        test_size=train_cfg["validation_size"],
        random_state=trial.number,
        stratify=y_train,
    )

    # Sample max_depth first so num_leaves can be constrained to a valid range.
    # In LightGBM, num_leaves > 2^max_depth produces redundant leaves and wastes compute.
    max_depth = trial.suggest_int("max_depth", *search_space["max_depth"])
    num_leaves_upper = min(search_space["num_leaves"][1], 2**max_depth - 1)
    num_leaves_lower = min(search_space["num_leaves"][0], num_leaves_upper)

    params = {
        "objective": train_cfg["model_objective"],
        "n_jobs": train_cfg["n_jobs"],
        "random_state": train_cfg["random_state"],
        "n_estimators": trial.suggest_int("n_estimators", *search_space["n_estimators"]),
        "learning_rate": trial.suggest_float(
            "learning_rate", *search_space["learning_rate"], log=True
        ),
        "max_depth": max_depth,
        "num_leaves": trial.suggest_int("num_leaves", num_leaves_lower, num_leaves_upper),
        "min_child_samples": trial.suggest_int(
            "min_child_samples", *search_space["min_child_samples"]
        ),
        "subsample": trial.suggest_float("subsample", *search_space["subsample"]),
        "colsample_bytree": trial.suggest_float(
            "colsample_bytree", *search_space["colsample_bytree"]
        ),
    }

    model = LGBMClassifier(**params, verbosity=-1)
    model.fit(X_sub, y_sub)
    y_pred = model.predict(X_val)
    return f1_score(y_val, y_pred, zero_division=0)


def run_hyperparameter_search(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    cfg: dict[str, Any],
) -> dict[str, Any]:
    """Run Optuna hyperparameter search and return the best parameters.

    Args:
        X_train: Training features.
        y_train: Training labels.
        cfg: Full configuration dict.

    Returns:
        Dictionary of best hyperparameters found.
    """
    n_trials = cfg["training"]["n_trials"]
    logger.info(f"Starting hyperparameter search with {n_trials} trials.")

    study = optuna.create_study(direction="maximize")
    study.optimize(
        lambda trial: objective(trial, X_train, y_train, cfg),
        n_trials=n_trials,
        show_progress_bar=True,
    )

    best_params = study.best_params
    logger.info(f"Best hyperparameters: {best_params}")
    logger.info(f"Best validation F1: {study.best_value:.4f}")
    return best_params


def train_final_model(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    best_params: dict[str, Any],
    cfg: dict[str, Any],
) -> LGBMClassifier:
    """Train the final LightGBM model on the full training set.

    Args:
        X_train: Training features.
        y_train: Training labels.
        best_params: Hyperparameters found by Optuna.
        cfg: Full configuration dict.

    Returns:
        Fitted LGBMClassifier.
    """
    train_cfg = cfg["training"]
    params = {
        "objective": train_cfg["model_objective"],
        "n_jobs": train_cfg["n_jobs"],
        "random_state": train_cfg["random_state"],
        **best_params,
    }
    logger.info(f"Training final model with params: {params}")
    model = LGBMClassifier(**params, verbosity=-1)
    model.fit(X_train, y_train)
    return model
