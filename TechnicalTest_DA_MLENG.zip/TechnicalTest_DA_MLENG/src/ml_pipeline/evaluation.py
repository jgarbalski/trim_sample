import json
import logging
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
)

logger = logging.getLogger(__name__)

# _METRIC_FNS is a lookup table mapping a metric name string to its actual function.
# This is a key design decision, instead of a big if/elif chain, I just look up the function by name and call it.
# Adding a new metric later means just adding one line to this dict.

_METRIC_FNS = {
    "accuracy": accuracy_score,
    "precision": precision_score,
    "recall": recall_score,
    "f1": f1_score,
}


def evaluate_model(
    y_pred: np.ndarray,
    y_test: pd.Series,
    metrics: list[str],
) -> dict[str, float]:
    results: dict[str, float] = {}
    for metric in metrics:
        fn = _METRIC_FNS.get(metric)
        if fn is None:
            logger.warning(f"Unknown metric '{metric}', skipping.")
            continue
        results[metric] = float(fn(y_test, y_pred))
        logger.info(f"{metric}: {results[metric]:.4f}")
    return results


def save_metrics(metrics: dict[str, float], artifacts_dir: str | Path, file_name: str) -> Path:
    output_path = Path(artifacts_dir) / file_name
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(metrics, f, indent=2)
    logger.info(f"Metrics saved to {output_path}")
    return output_path


def plot_confusion_matrix(
    y_pred: np.ndarray,
    y_test: pd.Series,
    artifacts_dir: str | Path,
    file_name: str,
) -> Path:
    output_path = Path(artifacts_dir) / file_name
    output_path.parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(6, 5))
    ConfusionMatrixDisplay.from_predictions(y_test, y_pred, ax=ax)
    ax.set_title("Confusion Matrix")
    fig.tight_layout()
    fig.savefig(output_path)
    # without below line matplotlib would keep the figure in memory. If this function would be called many times it would leak memory.
    plt.close(fig)
    logger.info(f"Confusion matrix saved to {output_path}")
    return output_path


def save_model(model: LGBMClassifier, artifacts_dir: str | Path, file_name: str) -> Path:
    # joblib is only imported if I actually call this function, not when the module is first loaded, minor optimisation
    import joblib

    output_path = Path(artifacts_dir) / file_name
    output_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, output_path)
    logger.info(f"Model saved to {output_path}")
    return output_path
