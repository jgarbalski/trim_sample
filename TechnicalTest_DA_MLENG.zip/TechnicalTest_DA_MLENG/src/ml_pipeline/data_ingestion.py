import io
import logging
from pathlib import Path
from typing import Any

import pandas as pd
import requests
import rdata

logger = logging.getLogger(__name__)


def download_data(url: str, raw_dir: str | Path, file_name: str) -> Path:
    output_path = Path(raw_dir) / file_name
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if output_path.exists():
        logger.info(f"Data file already exists at {output_path}, skipping download.")
        return output_path

    logger.info(f"Downloading data from {url}")
    response = requests.get(url, timeout=60)
    response.raise_for_status()

    f = io.BytesIO(response.content)
    df = rdata.read_rda(f)["pg15training"]
    df.to_csv(output_path, index=False)
    logger.info(f"Data saved to {output_path}")
    return output_path


def load_data(file_path: str | Path) -> pd.DataFrame:
    path = Path(file_path)
    logger.info(f"Loading data from {path}")
    return pd.read_csv(path)


def validate_raw_data(df: pd.DataFrame, cfg: dict[str, Any]) -> None:
    if df.empty:
        raise ValueError("Raw data is empty.")

    prep_cfg = cfg["preprocessing"]
    required_columns = (
        {prep_cfg["target_source_column"]}
        | set(prep_cfg["columns_to_drop"])
        | set(prep_cfg["categorical_columns"])
    )
    missing = required_columns - set(df.columns)
    if missing:
        raise ValueError(f"Raw data is missing expected columns: {missing}")

    logger.info(f"Data validation passed: {len(df)} rows, {len(df.columns)} columns.")
