import logging
from typing import Any

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder

logger = logging.getLogger(__name__)


def create_target(df: pd.DataFrame, source_column: str, target_column: str) -> pd.DataFrame:
    """Create a binary target column from a count column.

    Maps non-zero values to 1 (claim occurred) and zero to 0 (no claim).

    Args:
        df: Input DataFrame.
        source_column: Column whose non-zero values indicate a positive class.
        target_column: Name for the new binary target column.

    Returns:
        DataFrame with the target column added.
    """
    df = df.copy()
    df[target_column] = (df[source_column] != 0).astype(int)
    logger.info(f"Created target '{target_column}': {df[target_column].sum()} positives out of {len(df)} rows.")
    return df


def drop_columns(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    """Drop specified columns from the DataFrame.

    Args:
        df: Input DataFrame.
        columns: List of column names to drop.

    Returns:
        DataFrame with the columns removed.
    """
    # if the config lists a column that isn't in the data, below line handles it gracefully instead of crashing
    existing = [c for c in columns if c in df.columns]
    missing = set(columns) - set(existing)
    if missing:
        logger.warning(f"Columns not found and skipped: {missing}")
    return df.drop(columns=existing)


def fit_encoder(X: pd.DataFrame, categorical_columns: list[str]) -> OneHotEncoder:
    """Fit a OneHotEncoder on the categorical columns of the training set.

    Using sklearn's OneHotEncoder instead of pd.get_dummies prevents training/
    serving skew: the encoder remembers the exact categories seen at training time
    and applies the same schema at inference. Unknown categories are encoded as
    all-zeros rather than causing a crash (handle_unknown='ignore').

    Args:
        X: Training feature DataFrame.
        categorical_columns: Columns to encode.

    Returns:
        Fitted OneHotEncoder.
    """
    encoder = OneHotEncoder(sparse_output=False, handle_unknown="ignore")
    encoder.fit(X[categorical_columns])
    logger.info("Encoder fitted on %d categorical columns.", len(categorical_columns))
    return encoder


def apply_encoder(
    X: pd.DataFrame,
    encoder: OneHotEncoder,
    categorical_columns: list[str],
) -> pd.DataFrame:
    """Apply a fitted OneHotEncoder to a DataFrame.

    Replaces the original categorical columns with the encoded dummy columns,
    preserving all other columns and the original index.

    Args:
        X: Feature DataFrame.
        encoder: A fitted OneHotEncoder (from fit_encoder).
        categorical_columns: The same columns that were passed to fit_encoder.

    Returns:
        DataFrame with categorical columns replaced by one-hot encoded columns.
    """
    encoded = encoder.transform(X[categorical_columns])
    feature_names = encoder.get_feature_names_out(categorical_columns)
    encoded_df = pd.DataFrame(encoded, columns=feature_names, index=X.index)
    return X.drop(columns=categorical_columns).join(encoded_df)


def split_data(
    df: pd.DataFrame,
    target_column: str,
    test_size: float = 0.2,
    random_state: int = 42,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """Split a DataFrame into train and test feature/label sets.

    Uses stratified splitting to preserve the class ratio in both sets,
    which is critical for imbalanced datasets like this one.

    Args:
        df: Full processed DataFrame containing features and target.
        target_column: Name of the target column.
        test_size: Proportion of data to use for testing.
        random_state: Seed for reproducibility.

    Returns:
        Tuple of (X_train, X_test, y_train, y_test).
    """
    X = df.drop(columns=[target_column])
    y = df[target_column]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    logger.info(f"Split data: {len(X_train)} train rows, {len(X_test)} test rows.")
    return X_train, X_test, y_train, y_test


def preprocess(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.DataFrame:
    """Run the base preprocessing pipeline on the raw DataFrame.

    Steps:
        1. Create binary target from the source column.
        2. Drop raw count/indicator columns (data leakage prevention).

    Note:
        Categorical encoding is intentionally excluded here. The encoder must
        be fitted on training data only (after the train/test split) to prevent
        information leakage from the test set into the encoder's category schema.
        Use fit_encoder / apply_encoder in the pipeline after splitting.

    Args:
        df: Raw DataFrame loaded from CSV.
        cfg: Full configuration dict.

    Returns:
        Processed DataFrame ready for splitting (categoricals still as strings).
    """
    prep_cfg = cfg["preprocessing"]
    df = create_target(df, prep_cfg["target_source_column"], prep_cfg["target_column"])
    df = drop_columns(df, prep_cfg["columns_to_drop"])
    return df
