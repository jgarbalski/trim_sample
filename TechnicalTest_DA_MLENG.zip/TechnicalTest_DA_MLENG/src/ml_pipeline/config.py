from pathlib import Path
from typing import Any

import yaml


DEFAULT_CONFIG_PATH = Path(__file__).parents[2] / "config" / "config.yaml"


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    config_path = Path(path) if path else DEFAULT_CONFIG_PATH
    with open(config_path) as f:
        # safe_load (vs load) is used because it refuses to execute arbitrary Python code embedded in the YAML giving it a bit of that security sauce
        return yaml.safe_load(f)
