import logging
from pathlib import Path
from typing import Any

from ml_pipeline.config import load_config
from ml_pipeline.data_ingestion import download_data, load_data, validate_raw_data
from ml_pipeline.evaluation import evaluate_model, plot_confusion_matrix, save_metrics, save_model
from ml_pipeline.preprocessing import apply_encoder, fit_encoder, preprocess, split_data
from ml_pipeline.training import run_hyperparameter_search, train_final_model

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
)
logger = logging.getLogger(__name__)


def run_pipeline(config_path: str | Path | None = None) -> dict[str, Any]:
    """Execute the full ML pipeline.

    Steps:
        1.  Load configuration.
        2.  Download raw data (skipped if already present).
        3.  Load data into a DataFrame.
        4.  Validate raw data schema.
        5.  Preprocess: create target, drop leakage columns.
        6.  Split into train / test sets (stratified).
        7.  Fit OneHotEncoder on training features only, apply to both sets.
        8.  Hyperparameter search with Optuna (F1 objective).
        9.  Train final LightGBM model on full training set.
        10. Run inference once, compute metrics and confusion matrix.
        11. Persist model, encoder, metrics, and confusion matrix to disk.

    Args:
        config_path: Optional path to a YAML config file. Defaults to
            config/config.yaml relative to the project root.

    Returns:
        Dictionary containing evaluation metrics.
    """
    cfg = load_config(config_path)

    data_cfg = cfg["data"]
    artifacts_dir = data_cfg["artifacts_dir"]

    csv_path = download_data(
        url=data_cfg["url"],
        raw_dir=data_cfg["raw_dir"],
        file_name=data_cfg["file_name"],
    )

    df = load_data(csv_path)

    validate_raw_data(df, cfg)

    df = preprocess(df, cfg)

    split_cfg = cfg["split"]
    X_train, X_test, y_train, y_test = split_data(
        df,
        target_column=cfg["preprocessing"]["target_column"],
        test_size=split_cfg["test_size"],
        random_state=split_cfg["random_state"],
    )

    categorical_columns = cfg["preprocessing"]["categorical_columns"]
    encoder = fit_encoder(X_train, categorical_columns)
    X_train = apply_encoder(X_train, encoder, categorical_columns)
    X_test = apply_encoder(X_test, encoder, categorical_columns)

    best_params = run_hyperparameter_search(X_train, y_train, cfg)

    model = train_final_model(X_train, y_train, best_params, cfg)

    y_pred = model.predict(X_test)

    eval_cfg = cfg["evaluation"]
    metrics = evaluate_model(y_pred, y_test, eval_cfg["metrics"])
    logger.info("Evaluation results: %s", metrics)

    save_metrics(metrics, artifacts_dir, eval_cfg["metrics_file"])
    plot_confusion_matrix(y_pred, y_test, artifacts_dir, eval_cfg["confusion_matrix_file"])
    save_model(model, artifacts_dir, eval_cfg["model_file"])
    save_model(encoder, artifacts_dir, eval_cfg["encoder_file"])

    return metrics


def main():
    metrics = run_pipeline(config_path=None)
    for name, value in metrics.items():
        logger.info("  %s: %.4f", name, value)


if __name__ == "__main__":
    main()
