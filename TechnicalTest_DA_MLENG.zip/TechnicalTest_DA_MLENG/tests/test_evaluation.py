import json
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from lightgbm import LGBMClassifier

from ml_pipeline.evaluation import evaluate_model, save_metrics, save_model


@pytest.fixture
def fitted_model():
    """A simple fitted LGBMClassifier for save_model tests."""
    X = pd.DataFrame({"f1": range(50), "f2": range(50)})
    y = pd.Series([0, 1] * 25)
    model = LGBMClassifier(n_estimators=5, random_state=42, verbosity=-1)
    model.fit(X, y)
    return model, X, y


class TestEvaluateModel:
    def test_returns_all_requested_metrics(self):
        y_pred = np.array([0, 1, 0, 1, 0, 1])
        y_test = pd.Series([0, 1, 0, 1, 0, 1])
        metrics = evaluate_model(y_pred, y_test, ["accuracy", "precision", "recall", "f1"])
        assert set(metrics.keys()) == {"accuracy", "precision", "recall", "f1"}

    def test_perfect_predictions_score_one(self):
        y_pred = np.array([0, 1, 0, 1])
        y_test = pd.Series([0, 1, 0, 1])
        metrics = evaluate_model(y_pred, y_test, ["accuracy", "f1"])
        assert metrics["accuracy"] == 1.0
        assert metrics["f1"] == 1.0

    def test_metric_values_in_range(self):
        y_pred = np.array([0, 1, 1, 0, 0, 1])
        y_test = pd.Series([0, 1, 0, 1, 0, 1])
        metrics = evaluate_model(y_pred, y_test, ["accuracy", "precision", "recall", "f1"])
        for val in metrics.values():
            assert 0.0 <= val <= 1.0

    def test_unknown_metric_skipped(self):
        y_pred = np.array([0, 1])
        y_test = pd.Series([0, 1])
        metrics = evaluate_model(y_pred, y_test, ["accuracy", "bogus_metric"])
        assert "bogus_metric" not in metrics
        assert "accuracy" in metrics

    def test_subset_of_metrics(self):
        y_pred = np.array([0, 1])
        y_test = pd.Series([0, 1])
        metrics = evaluate_model(y_pred, y_test, ["accuracy"])
        assert list(metrics.keys()) == ["accuracy"]


class TestSaveMetrics:
    def test_file_is_created(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            metrics = {"accuracy": 0.9, "f1": 0.85}
            path = save_metrics(metrics, tmpdir, "metrics.json")
            assert path.exists()

    def test_saved_content_matches(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            metrics = {"accuracy": 0.9, "f1": 0.85}
            path = save_metrics(metrics, tmpdir, "metrics.json")
            with open(path) as f:
                loaded = json.load(f)
            assert loaded == metrics

    def test_creates_parent_directory(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            nested = Path(tmpdir) / "nested" / "dir"
            save_metrics({"accuracy": 1.0}, nested, "m.json")
            assert (nested / "m.json").exists()


class TestSaveModel:
    def test_model_file_created(self, fitted_model):
        model, _, _ = fitted_model
        with tempfile.TemporaryDirectory() as tmpdir:
            path = save_model(model, tmpdir, "model.joblib")
            assert path.exists()

    def test_loaded_model_predicts(self, fitted_model):
        import joblib

        model, X, _ = fitted_model
        with tempfile.TemporaryDirectory() as tmpdir:
            path = save_model(model, tmpdir, "model.joblib")
            loaded_model = joblib.load(path)
            preds = loaded_model.predict(X)
            assert len(preds) == len(X)
