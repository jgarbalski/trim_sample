import pandas as pd
import pytest
from sklearn.preprocessing import OneHotEncoder

from ml_pipeline.preprocessing import (
    apply_encoder,
    create_target,
    drop_columns,
    fit_encoder,
    preprocess,
    split_data,
)


class TestCreateTarget:
    def test_zero_maps_to_zero(self):
        df = pd.DataFrame({"Numtppd": [0, 0, 0]})
        result = create_target(df, "Numtppd", "target")
        assert list(result["target"]) == [0, 0, 0]

    def test_nonzero_maps_to_one(self):
        df = pd.DataFrame({"Numtppd": [1, 2, 100]})
        result = create_target(df, "Numtppd", "target")
        assert list(result["target"]) == [1, 1, 1]

    def test_mixed_values(self):
        df = pd.DataFrame({"Numtppd": [0, 1, 0, 3]})
        result = create_target(df, "Numtppd", "target")
        assert list(result["target"]) == [0, 1, 0, 1]

    def test_original_column_preserved(self):
        df = pd.DataFrame({"Numtppd": [0, 1]})
        result = create_target(df, "Numtppd", "target")
        assert "Numtppd" in result.columns

    def test_does_not_mutate_input(self):
        df = pd.DataFrame({"Numtppd": [0, 1]})
        original_cols = set(df.columns)
        create_target(df, "Numtppd", "target")
        assert set(df.columns) == original_cols


class TestDropColumns:
    def test_drops_existing_columns(self):
        df = pd.DataFrame({"a": [1], "b": [2], "c": [3]})
        result = drop_columns(df, ["a", "b"])
        assert list(result.columns) == ["c"]

    def test_ignores_missing_columns(self):
        df = pd.DataFrame({"a": [1], "b": [2]})
        result = drop_columns(df, ["a", "z"])
        assert list(result.columns) == ["b"]

    def test_empty_list(self):
        df = pd.DataFrame({"a": [1], "b": [2]})
        result = drop_columns(df, [])
        assert list(result.columns) == ["a", "b"]


class TestFitEncoder:
    def test_returns_ohe(self):
        X = pd.DataFrame({"cat": ["a", "b", "a"], "num": [1, 2, 3]})
        encoder = fit_encoder(X, ["cat"])
        assert isinstance(encoder, OneHotEncoder)

    def test_encoder_knows_categories(self):
        X = pd.DataFrame({"color": ["red", "blue", "red"]})
        encoder = fit_encoder(X, ["color"])
        assert set(encoder.categories_[0]) == {"red", "blue"}

    def test_handles_unknown_categories_silently(self):
        X_train = pd.DataFrame({"color": ["red", "blue"]})
        X_new = pd.DataFrame({"color": ["green"]})
        encoder = fit_encoder(X_train, ["color"])
        # handle_unknown='ignore' means unseen categories encode as all-zeros, no crash
        result = apply_encoder(X_new, encoder, ["color"])
        assert result.shape[0] == 1


class TestApplyEncoder:
    def test_categorical_columns_replaced(self):
        X = pd.DataFrame({"color": ["red", "blue"], "num": [1, 2]})
        encoder = fit_encoder(X, ["color"])
        result = apply_encoder(X, encoder, ["color"])
        assert "color" not in result.columns
        assert any(c.startswith("color_") for c in result.columns)

    def test_numeric_columns_preserved(self):
        X = pd.DataFrame({"color": ["red", "blue"], "num": [1.0, 2.0]})
        encoder = fit_encoder(X, ["color"])
        result = apply_encoder(X, encoder, ["color"])
        assert "num" in result.columns
        assert result["num"].tolist() == [1.0, 2.0]

    def test_index_preserved(self):
        X = pd.DataFrame({"color": ["red", "blue"]}, index=[10, 20])
        encoder = fit_encoder(X, ["color"])
        result = apply_encoder(X, encoder, ["color"])
        assert list(result.index) == [10, 20]


class TestSplitData:
    def test_correct_split_sizes(self):
        df = pd.DataFrame({"f1": range(100), "f2": range(100), "target": [0, 1] * 50})
        X_train, X_test, y_train, y_test = split_data(df, "target", test_size=0.2, random_state=42)
        assert len(X_train) == 80
        assert len(X_test) == 20

    def test_target_not_in_features(self):
        df = pd.DataFrame({"f1": range(10), "target": [0, 1] * 5})
        X_train, X_test, _, _ = split_data(df, "target")
        assert "target" not in X_train.columns
        assert "target" not in X_test.columns

    def test_reproducible_with_same_seed(self):
        df = pd.DataFrame({"f1": range(50), "target": [0, 1] * 25})
        _, X_test_a, _, _ = split_data(df, "target", random_state=0)
        _, X_test_b, _, _ = split_data(df, "target", random_state=0)
        pd.testing.assert_frame_equal(X_test_a, X_test_b)

    def test_stratified_preserves_class_ratio(self):
        df = pd.DataFrame({"f1": range(100), "target": [0] * 90 + [1] * 10})
        _, _, y_train, y_test = split_data(df, "target", test_size=0.2, random_state=42)
        train_ratio = y_train.mean()
        test_ratio = y_test.mean()
        assert abs(train_ratio - test_ratio) < 0.05


class TestPreprocess:
    def test_target_column_created(self, sample_raw_df, sample_config):
        result = preprocess(sample_raw_df, sample_config)
        assert "target" in result.columns

    def test_dropped_columns_absent(self, sample_raw_df, sample_config):
        result = preprocess(sample_raw_df, sample_config)
        for col in ["Numtppd", "Numtpbi", "Indtppd", "Indtpbi"]:
            assert col not in result.columns

    def test_categorical_columns_still_present(self, sample_raw_df, sample_config):
        # preprocess no longer encodes — encoding happens after the split
        result = preprocess(sample_raw_df, sample_config)
        for col in sample_config["preprocessing"]["categorical_columns"]:
            assert col in result.columns

    def test_output_is_dataframe(self, sample_raw_df, sample_config):
        result = preprocess(sample_raw_df, sample_config)
        assert isinstance(result, pd.DataFrame)
