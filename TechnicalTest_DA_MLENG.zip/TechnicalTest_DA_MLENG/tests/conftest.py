import pandas as pd
import pytest


@pytest.fixture
def sample_raw_df() -> pd.DataFrame:
    """Small synthetic DataFrame mimicking the raw pg15training schema."""
    return pd.DataFrame(
        {
            "Numtppd": [0, 1, 0, 2, 0, 3, 0, 0, 1, 0],
            "Numtpbi": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            "Indtppd": [0, 1, 0, 1, 0, 1, 0, 0, 1, 0],
            "Indtpbi": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            "Exposure": [0.5, 1.0, 0.3, 0.8, 0.9, 1.0, 0.4, 0.7, 0.6, 1.0],
            "CalYear": ["2011", "2012", "2013", "2014", "2015", "2011", "2012", "2013", "2014", "2015"],
            "Gender": ["M", "F", "M", "F", "M", "F", "M", "F", "M", "F"],
            "Type": ["A", "B", "A", "B", "A", "B", "A", "B", "A", "B"],
            "Category": ["C1", "C2", "C1", "C2", "C1", "C2", "C1", "C2", "C1", "C2"],
            "Occupation": ["O1", "O2", "O1", "O2", "O1", "O2", "O1", "O2", "O1", "O2"],
            "SubGroup2": ["S1", "S2", "S1", "S2", "S1", "S2", "S1", "S2", "S1", "S2"],
            "Group2": ["G1", "G2", "G1", "G2", "G1", "G2", "G1", "G2", "G1", "G2"],
            "Group1": ["GG1", "GG2", "GG1", "GG2", "GG1", "GG2", "GG1", "GG2", "GG1", "GG2"],
        }
    )


@pytest.fixture
def sample_config() -> dict:
    """Minimal configuration mirroring config/config.yaml."""
    return {
        "data": {
            "url": "http://example.com/data.rda",
            "raw_dir": "data/raw",
            "processed_dir": "data/processed",
            "artifacts_dir": "data/artifacts",
            "file_name": "pg15training.csv",
        },
        "preprocessing": {
            "target_column": "target",
            "target_source_column": "Numtppd",
            "columns_to_drop": ["Numtppd", "Numtpbi", "Indtppd", "Indtpbi"],
            "categorical_columns": [
                "CalYear",
                "Gender",
                "Type",
                "Category",
                "Occupation",
                "SubGroup2",
                "Group2",
                "Group1",
            ],
        },
        "split": {"test_size": 0.2, "random_state": 42},
        "training": {
            "n_trials": 2,
            "validation_size": 0.2,
            "random_state": 42,
            "model_objective": "binary",
            "n_jobs": 1,
            "hyperparameter_search_space": {
                "n_estimators": [5, 10],
                "learning_rate": [0.01, 0.1],
                "max_depth": [3, 5],
                "num_leaves": [10, 20],
                "min_child_samples": [1, 5],
                "subsample": [0.8, 1.0],
                "colsample_bytree": [0.8, 1.0],
            },
        },
        "evaluation": {
            "metrics": ["accuracy", "precision", "recall", "f1"],
            "confusion_matrix_file": "confusion_matrix.png",
            "metrics_file": "metrics.json",
            "model_file": "model.joblib",
            "encoder_file": "encoder.joblib",
        },
    }
