import tempfile
from pathlib import Path

import pandas as pd
import pytest

from ml_pipeline.data_ingestion import load_data, validate_raw_data


class TestLoadData:
    def test_loads_csv_correctly(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            csv_path = Path(tmpdir) / "test.csv"
            df_expected = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
            df_expected.to_csv(csv_path, index=False)
            df_loaded = load_data(csv_path)
            pd.testing.assert_frame_equal(df_loaded, df_expected)

    def test_returns_dataframe(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            csv_path = Path(tmpdir) / "test.csv"
            pd.DataFrame({"x": [1]}).to_csv(csv_path, index=False)
            result = load_data(csv_path)
            assert isinstance(result, pd.DataFrame)

    def test_raises_on_missing_file(self):
        with pytest.raises(FileNotFoundError):
            load_data("/nonexistent/path/data.csv")


class TestValidateRawData:
    def test_passes_on_valid_data(self, sample_raw_df, sample_config):
        # should not raise
        validate_raw_data(sample_raw_df, sample_config)

    def test_raises_on_empty_dataframe(self, sample_config):
        with pytest.raises(ValueError, match="empty"):
            validate_raw_data(pd.DataFrame(), sample_config)

    def test_raises_on_missing_columns(self, sample_config):
        df = pd.DataFrame({"only_this_col": [1, 2]})
        with pytest.raises(ValueError, match="missing expected columns"):
            validate_raw_data(df, sample_config)

    def test_raises_only_for_missing_not_extra(self, sample_raw_df, sample_config):
        # extra columns are fine, validation should pass
        df = sample_raw_df.copy()
        df["extra_col"] = 999
        validate_raw_data(df, sample_config)
