import pandas as pd
import pytest
import optuna

from ml_pipeline.training import objective, train_final_model


@pytest.fixture
def small_training_data():
    """Small balanced dataset for fast training tests."""
    X = pd.DataFrame({"f1": list(range(40)), "f2": list(range(40, 80))})
    y = pd.Series([0, 1] * 20)
    return X, y


class TestObjective:
    def test_returns_float(self, small_training_data, sample_config):
        X, y = small_training_data
        study = optuna.create_study(direction="maximize")
        study.optimize(lambda t: objective(t, X, y, sample_config), n_trials=1)
        assert isinstance(study.best_value, float)

    def test_value_between_zero_and_one(self, small_training_data, sample_config):
        X, y = small_training_data
        study = optuna.create_study(direction="maximize")
        study.optimize(lambda t: objective(t, X, y, sample_config), n_trials=1)
        assert 0.0 <= study.best_value <= 1.0

    def test_different_trials_use_different_splits(self, small_training_data, sample_config):
        # Each trial uses trial.number as its random_state, so splits differ.
        # We verify by running two trials and checking both complete without error.
        X, y = small_training_data
        study = optuna.create_study(direction="maximize")
        study.optimize(lambda t: objective(t, X, y, sample_config), n_trials=2)
        assert len(study.trials) == 2


class TestTrainFinalModel:
    def test_model_is_fitted(self, small_training_data, sample_config):
        from lightgbm import LGBMClassifier

        X, y = small_training_data
        best_params = {
            "n_estimators": 5, "learning_rate": 0.05, "max_depth": 3,
            "num_leaves": 7, "min_child_samples": 1,
            "subsample": 1.0, "colsample_bytree": 1.0,
        }
        model = train_final_model(X, y, best_params, sample_config)
        assert isinstance(model, LGBMClassifier)
        assert hasattr(model, "booster_")

    def test_model_can_predict(self, small_training_data, sample_config):
        X, y = small_training_data
        best_params = {
            "n_estimators": 5, "learning_rate": 0.05, "max_depth": 3,
            "num_leaves": 7, "min_child_samples": 1,
            "subsample": 1.0, "colsample_bytree": 1.0,
        }
        model = train_final_model(X, y, best_params, sample_config)
        preds = model.predict(X)
        assert len(preds) == len(X)
        assert set(preds).issubset({0, 1})

    def test_model_has_random_state(self, small_training_data, sample_config):
        X, y = small_training_data
        best_params = {
            "n_estimators": 5, "learning_rate": 0.05, "max_depth": 3,
            "num_leaves": 7, "min_child_samples": 1,
            "subsample": 1.0, "colsample_bytree": 1.0,
        }
        model = train_final_model(X, y, best_params, sample_config)
        assert model.random_state == sample_config["training"]["random_state"]
