import tempfile

import pandas as pd
import pytest

from ml_pipeline.data_ingestion import validate_raw_data
from ml_pipeline.evaluation import evaluate_model, save_metrics, save_model
from ml_pipeline.preprocessing import apply_encoder, fit_encoder, preprocess, split_data
from ml_pipeline.training import run_hyperparameter_search, train_final_model


def test_full_pipeline_on_synthetic_data(sample_raw_df, sample_config):
    """Run the entire pipeline on synthetic data without downloading anything."""
    # 1. Validate
    validate_raw_data(sample_raw_df, sample_config)

    # 2. Preprocess (target creation + drop leakage columns, no encoding)
    df = preprocess(sample_raw_df, sample_config)
    assert "target" in df.columns
    for col in sample_config["preprocessing"]["categorical_columns"]:
        assert col in df.columns  # still present — encoding happens after split

    # 3. Split (stratified)
    X_train, X_test, y_train, y_test = split_data(
        df,
        target_column=sample_config["preprocessing"]["target_column"],
        test_size=sample_config["split"]["test_size"],
        random_state=sample_config["split"]["random_state"],
    )
    assert len(X_train) > 0
    assert len(X_test) > 0

    # 4. Fit encoder on train only, apply to both
    categorical_columns = sample_config["preprocessing"]["categorical_columns"]
    encoder = fit_encoder(X_train, categorical_columns)
    X_train_enc = apply_encoder(X_train, encoder, categorical_columns)
    X_test_enc = apply_encoder(X_test, encoder, categorical_columns)
    for col in categorical_columns:
        assert col not in X_train_enc.columns
        assert col not in X_test_enc.columns

    # 5. Hyperparameter search
    best_params = run_hyperparameter_search(X_train_enc, y_train, sample_config)
    assert isinstance(best_params, dict)
    assert "n_estimators" in best_params

    # 6. Train final model
    model = train_final_model(X_train_enc, y_train, best_params, sample_config)
    assert hasattr(model, "booster_")

    # 7. Predict once, evaluate
    import numpy as np
    y_pred = model.predict(X_test_enc)
    assert isinstance(y_pred, np.ndarray)

    metrics = evaluate_model(y_pred, y_test, sample_config["evaluation"]["metrics"])
    assert set(metrics.keys()) == {"accuracy", "precision", "recall", "f1"}
    for val in metrics.values():
        assert 0.0 <= val <= 1.0

    # 8. Persist artefacts
    with tempfile.TemporaryDirectory() as tmpdir:
        metrics_path = save_metrics(metrics, tmpdir, "metrics.json")
        model_path = save_model(model, tmpdir, "model.joblib")
        encoder_path = save_model(encoder, tmpdir, "encoder.joblib")
        assert metrics_path.exists()
        assert model_path.exists()
        assert encoder_path.exists()
